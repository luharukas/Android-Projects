package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.util.*;
import java.util.regex.Pattern;

import android.widget.*;
import android.view.*;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0,btndot,btnplus,btnsub,btnmul,btndiv,btnequal,btnclear;
    TextView textresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1=(Button)findViewById(R.id.button1);
        btn1.setOnClickListener(this);
        btn2=(Button)findViewById(R.id.button2);
        btn2.setOnClickListener(this);
        btn3=(Button)findViewById(R.id.button3);
        btn3.setOnClickListener(this);
        btn4=(Button)findViewById(R.id.button4);
        btn4.setOnClickListener(this);
        btn5=(Button)findViewById(R.id.button5);
        btn5.setOnClickListener(this);
        btn6=(Button)findViewById(R.id.button6);
        btn6.setOnClickListener(this);
        btn7=(Button)findViewById(R.id.button7);
        btn7.setOnClickListener(this);
        btn8=(Button)findViewById(R.id.button8);
        btn8.setOnClickListener(this);
        btn9=(Button)findViewById(R.id.button9);
        btn9.setOnClickListener(this);
        btn0=(Button)findViewById(R.id.button0);
        btn0.setOnClickListener(this);
        btndot=(Button)findViewById(R.id.button_dot);
        btndot.setOnClickListener(this);
        btnplus=(Button)findViewById(R.id.button_plus);
        btnplus.setOnClickListener(this);
        btnsub=(Button)findViewById(R.id.button_sub);
        btnsub.setOnClickListener(this);
        btnmul=(Button)findViewById(R.id.button_mul);
        btnmul.setOnClickListener(this);
        btndiv=(Button)findViewById(R.id.button_div);
        btndiv.setOnClickListener(this);
        btnequal=(Button)findViewById(R.id.button_equal);
        btnequal.setOnClickListener(this);
        btnclear=(Button)findViewById(R.id.button_ce);
        btnclear.setOnClickListener(this);

        textresult=(EditText)findViewById(R.id.display);
        textresult.setText("");
    }

    @Override
    public void onClick(View v) {

        if (v.equals(btn1))
            textresult.append("1");
        if (v.equals(btn2))
            textresult.append("2");
        if (v.equals(btn3))
            textresult.append("3");
        if (v.equals(btn4))
            textresult.append("4");
        if (v.equals(btn5))
            textresult.append("5");
        if (v.equals(btn6))
            textresult.append("6");
        if (v.equals(btn7))
            textresult.append("7");
        if (v.equals(btn8))
            textresult.append("8");
        if (v.equals(btn9))
            textresult.append("9");
        if (v.equals(btn0))
            textresult.append("0");
        if (v.equals(btndot))
            textresult.append(".");
        if (v.equals(btnplus))
            textresult.append("+");
        if (v.equals(btnsub))
            textresult.append("-");
        if (v.equals(btnmul))
            textresult.append("*");
        if (v.equals(btndiv))
            textresult.append("/");
        if (v.equals(btnclear))
            textresult.setText("");
        if (v.equals(btnequal))
        {
            try{
                String eqn=textresult.getText().toString();
                if (eqn.contains("/")){
                    String[] operand=eqn.split("/");
                    if (operand.length==2){
                        double operand1 = Double.parseDouble(operand[0]);
                        double operand2 = Double.parseDouble(operand[1]);
                        double result=operand1/operand2;
                        textresult.setText(String.valueOf(result));
                    }else{
                        Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
                    }
                }
                else if (eqn.contains("*")){
                    String[] operand=eqn.split(Pattern.quote("*"));
                    if (operand.length==2){
                        double operand1 = Double.parseDouble(operand[0]);
                        double operand2 = Double.parseDouble(operand[1]);
                        double result=operand1*operand2;
                        textresult.setText(String.valueOf(result));
                    }else{
                        Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
                    }

                }
                else if (eqn.contains("+")){
                    String[] operand=eqn.split(Pattern.quote("+"));
                    if (operand.length==2){
                        double operand1 = Double.parseDouble(operand[0]);
                        double operand2 = Double.parseDouble(operand[1]);
                        double result=operand1+operand2;
                        textresult.setText(String.valueOf(result));
                    }else{
                        Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
                    }

                }else if (eqn.contains("-")){
                    String[] operand=eqn.split("-");
                    if (operand.length==2){
                        double operand1 = Double.parseDouble(operand[0]);
                        double operand2 = Double.parseDouble(operand[1]);
                        double result=operand1-operand2;
                        textresult.setText(String.valueOf(result));
                    }else{
                        Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
                    }

                }else{
                    Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
                }

            } catch (Exception e){
                Toast.makeText(getBaseContext(),"INVALID INPUT",Toast.LENGTH_LONG).show();
            }
        }



    }
}